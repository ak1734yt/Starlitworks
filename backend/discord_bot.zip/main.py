import os
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from dotenv import load_dotenv
from database import init_db
from notifications import start_notification_service

load_dotenv()
init_db()
start_notification_service()

from discord_stats import start_discord_stats_loop
start_discord_stats_loop()

# Start Discord Operations Bot in the background
def start_discord_bot_background():
    import threading
    import asyncio
    from discord_bot import start_discord_bot
    
    def _run():
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            loop.run_until_complete(start_discord_bot())
        except Exception as e:
            print(f"[BOT] Startup failed: {e}")
        finally:
            loop.close()
        
    threading.Thread(target=_run, daemon=True).start()

if os.getenv("DISCORD_BOT_TOKEN"):
    start_discord_bot_background()


FRONTEND_URL = os.getenv("FRONTEND_URL", "http://localhost:5173")

app = FastAPI(title="Starlit Siege Works API", version="2.0.0", docs_url="/docs")

# ── CORS ──────────────────────────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        FRONTEND_URL,
        "https://starlitworks.vercel.app",   # production frontend
        "http://localhost:5173",              # local dev (Vite)
        "http://127.0.0.1:5173",
    ],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["Content-Type", "Authorization", "X-Starlit-Key"],
)

# ── Static file serving (uploads) ─────────────────────────────────────────────
DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
UPLOADS_DIR = os.path.join(DATA_DIR, "uploads")
os.makedirs(UPLOADS_DIR, exist_ok=True)
app.mount("/uploads", StaticFiles(directory=UPLOADS_DIR), name="uploads")

# ── Security Middleware ───────────────────────────────────────────────────────
@app.middleware("http")
async def security_header_check(request: Request, call_next):
    if request.url.path.startswith("/api/"):
        exempt_prefixes = [
            "/api/health",
            "/api/auth/google",
            "/api/auth/discord",
            "/api/auth/microsoft",
            "/api/auth/apple"
        ]
        if not any(request.url.path.startswith(prefix) for prefix in exempt_prefixes):
            starlit_key = request.headers.get("X-Starlit-Key")
            expected_key = os.getenv("JWT_SECRET", "b3b985dfebb6061ef6c960d20dbf0cfea3e56a2f34675a0755f32204a37491ca7c69faec1605e42bcafc7d90f91bab7160ce3291bbeef94449155427f695457c")
            if not starlit_key or starlit_key != expected_key:
                from fastapi.responses import JSONResponse
                return JSONResponse(status_code=403, content={"error": "Security Check Failed: Unauthorized API Access"})
            
    response = await call_next(request)
    
    # Inject HTTP Hardening Security Headers
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; "
        "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://apis.google.com; "
        "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
        "font-src 'self' data: https://fonts.gstatic.com; "
        "img-src 'self' data: https:; "
        "connect-src 'self' https:; "
        "frame-ancestors 'none';"
    )
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Strict-Transport-Security"] = "max-age=63072000; includeSubDomains; preload"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    
    return response

# ── Route Injection ───────────────────────────────────────────────────────────
from routers import auth_routes, order_routes, chat_routes, admin_routes, analytics_routes, invoice_routes, payment_routes, oauth_routes, referral_routes

app.include_router(auth_routes.router, prefix="/api")
app.include_router(oauth_routes.router, prefix="/api")
app.include_router(order_routes.router, prefix="/api")
app.include_router(chat_routes.router, prefix="/api")
app.include_router(admin_routes.router, prefix="/api")
app.include_router(analytics_routes.router, prefix="/api")
app.include_router(invoice_routes.router, prefix="/api")
app.include_router(payment_routes.router, prefix="/api")
app.include_router(referral_routes.router, prefix="/api")

@app.get("/")
def root():
    return {"message": "Starlit Siege Works API v2.0 — Python/FastAPI", "status": "online", "docs": "/docs"}

@app.get("/api/health")
def health_check():
    return {"status": "online", "core": "optimal"}

# ── Run (EnderCloud / local) ───────────────────────────────────────────────────
if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", 5504))
    uvicorn.run("main:app", host="0.0.0.0", port=port, reload=True)
